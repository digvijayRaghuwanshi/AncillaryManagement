import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { CheckInComponent } from './check-in/check-in.component';
import { InFlightComponent } from './in-flight/in-flight.component';
import { HomeRoutingModule } from './home-routing';
import { HttpClientModule } from '@angular/common/http';


@NgModule({
  declarations: [
    CheckInComponent,
    InFlightComponent,
  ],
  imports: [CommonModule, HomeRoutingModule, HttpClientModule],
})
export class HomeModule { }
