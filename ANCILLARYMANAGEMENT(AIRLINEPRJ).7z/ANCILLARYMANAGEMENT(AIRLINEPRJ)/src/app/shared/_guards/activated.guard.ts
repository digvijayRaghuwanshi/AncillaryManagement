import { Injectable } from '@angular/core';
import {
  CanActivate,
  ActivatedRouteSnapshot,
  RouterStateSnapshot,
  UrlTree,
  Router,
} from '@angular/router';
import { Observable } from 'rxjs';
import { CommonService } from 'src/app/common.service';

@Injectable({
  providedIn: 'root',
})
export class ActivatedGuard implements CanActivate {
  constructor(private userService: CommonService, private router: Router) {}
  canActivate(
    route: ActivatedRouteSnapshot,
    state: RouterStateSnapshot
  ):
    | Observable<boolean | UrlTree>
    | Promise<boolean | UrlTree>
    | boolean
    | UrlTree {
    if (this.userService.sendData) {
      return true;
    } else {
      alert('You dont have permission');
      this.router.navigate(['login']);
    }
  }
}
